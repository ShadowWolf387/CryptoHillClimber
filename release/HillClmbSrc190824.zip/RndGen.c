/****************************************************************************
* RndGen.c
*
* Generates random numbers (0 - 25) using various methods.  
****************************************************************************/
#include <stdlib.h>
#include <time.h>
#include "Globals.h"
#include "RndGen.h"

#define random(num) (rand()%(num))
#define randomize() srand((unsigned)time(NULL))

/* FIBPRNG sizes and limits constants. Change at your own risk. */
#ifdef FIBRNG
#define SEEDSIZE 26
#define INITLOOP 2600
#define ARRYSIZE 75
#define PNTRSIZE 3
/* RndGen variables */
int rndarray[ARRYSIZE],rndpoint[PNTRSIZE],rndsel;
#endif

#ifdef LCGRNG
/* Linear congruential generator variables */
unsigned int LcgSeed;
#endif

#ifdef TBLRNG
/* Random Table */
/*int RndTbl[26]={8,19,7,0,12,18,14,1,4,23,2,17,16,
					10,22,5,24,13,25,9,3,20,11,15,6,21};*/
int r4;
#endif

int RndSel(int r){
	if(r>'Z')r-=32;
	switch(r){
#ifdef FIBRNG
		case 'F':
			RndInit=Rnd1Init;
			RndGen=Rnd1Gen;
			break;
#endif
#ifdef LCGRNG
		case 'L':
			RndInit=Rnd2Init;
			RndGen=Rnd2Gen;
			break;
#endif
#ifdef LIBRNG
		case 'R':
			RndInit=Rnd3Init;
			RndGen=Rnd3Gen;
			break;
#endif
#ifdef TBLRNG
		case 'T':
			RndInit=Rnd4Init;
			RndGen=Rnd4Gen;
			break;
#endif
		default:
			printf("ERROR: Unknown random number generator type.\n");
			return 1;
			break;
	}
	return 0;
}
#ifdef FIBRNG
/* Fibonacci generator */
void Rnd1Init(void){
	int x;
	rndsel=2;
	rndpoint[0]=0;
	rndpoint[1]=3;
	rndpoint[2]=SEEDSIZE;
	for(x=0;x<SEEDSIZE;x++)rndarray[x]=BstKey[x];
	for(x=0;x<INITLOOP;x++)RndGen();
}
int Rnd1Gen(void){
	int rtn;
	rtn=rndarray[rndpoint[0]]+rndarray[rndpoint[1]];
	while(rtn>RNDSIZE-1)rtn-=RNDSIZE;
	rndarray[rndpoint[2]]=rtn;
	rndpoint[0]++;
	rndpoint[1]++;
	rndpoint[2]++;
	if(rndpoint[rndsel]>ARRYSIZE-1){
		rndpoint[rndsel]=0;
		rndsel--;
		if(rndsel<0)rndsel=2;
	}
	return rtn;
}
#endif
#ifdef LCGRNG
/* Linear Congruential Generator */
void Rnd2Init(void){
	randomize();
	LcgSeed=random(714023);
} 
int Rnd2Gen(void){
	static unsigned int rtn;
	rtn=(4096*LcgSeed+150889)%714025;
	LcgSeed=rtn;
	return rtn%26;
}
#endif
#ifdef LIBRNG
/* C library rand() function */
void Rnd3Init(void){
	randomize();
	//srand(1);
} 
int Rnd3Gen(void){
	return random(26);
}
#endif
#ifdef TBLRNG
/* Random Table */
void Rnd4Init(void){
	r4=0;
} 
int Rnd4Gen(void){
	/* Random Table */
	int RndTbl[26]={8,19,7,0,12,18,14,1,4,23,2,17,16,
								10,22,5,24,13,25,9,3,20,11,15,6,21};
	static int rtn;
	
	rtn=RndTbl[r4];
	r4++;
	if(r4>25)r4=0;
	return rtn;
}
#endif
 
