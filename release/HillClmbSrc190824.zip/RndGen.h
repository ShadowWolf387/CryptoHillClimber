/****************************************************************************
* RndGen.h
*
* Header for RndGen.c
* See RndGen.c for details. Some things may be incomplete 
****************************************************************************/
#define FIBRNG		/* Fibonacci style PRNG. No Multiplication or modulus */
#define LCGRNG		/* Linear Congruential Generator */
#define LIBRNG		/* C library PRNG */
#define TBLRNG		/* Table based random numbers */


#define RNDSIZE 26

int RndSel(int r);
void (*RndInit)(void);		/* Pointer to allow dynamic switching */
int (*RndGen)(void);		/* Pointer to allow dynamic switching */

#ifdef FIBRNG
void Rnd1Init(void);
int Rnd1Gen(void);
#endif
#ifdef LCGRNG
void Rnd2Init(void);
int Rnd2Gen(void);
#endif
#ifdef LIBRNG
void Rnd3Init(void);
int Rnd3Gen(void);
#endif
#ifdef TBLRNG
void Rnd4Init(void);
int Rnd4Gen(void);
#endif

