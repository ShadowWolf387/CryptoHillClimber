/****************************************************************************
* MonoAlph.h
*
* Header for MonoAlph.c
* See MonoAlph.c for details 
****************************************************************************/

/**************************************************************************** 
* Keygen types available (Select one)
* ! Some Keygen functions may not be implemented or working yet.
****************************************************************************/
#define RANDOM		/* 1 Random swaps. Similar to fractal filling */
#define SLCTSRCH	/* 2 Selection sort random table swaps */
#define WALKSRCH  /* 3 A walking search with just 1 random element. */
#define CKTLSRCH	/* 4 ! Bi-directional bubble swaps (fail)*/
#define EXPRMNT		/* 9 ! Unknown. Use at your own risk. */

#define KEYSZ 26 

/* Function Definitions */
void InitKey(void);
void GenKeyR(void);
void GenKeyS(void);
void GenKeyW(void);
void GenKeyC(void);
void GenKeyE(void);
void Shotgun(void);
void Decrypt(void);
void SwapKey(void);
void ReadKey(void);
void WriteKey(void);

