/****************************************************************************
* main.c
* All the initilization code.
*
* Look at the <algorithm>.c file for cipher handling.
* Cipher is treated like a C++ class.
****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include "Globals.h"
#include "MonoAlph.h"
#include "HillClimb.h"
#include "Core.h"

void usage(void);

int main(int argc, char *argv[]){
	int x;
	int sgcnt,EnableSG=0,sglmt=0;

	/* Check number of args */
	if(argc<5||argc>6){
		printf("ERROR: Wrong number of args.\n\n");
		usage();
		return 1;
	}
	if(argc==6){
		/* Read start key */
		if((fk=fopen(argv[5],"rt"))==NULL){
			printf("ERROR: Key file open failed.\n\n");
			return 1;
		}
		ReadKey();
		fclose(fk);
	}else{
		/* Init key to std alphabet */
		for(x=0;x<KEYSIZE;x++)BstKey[x]=NewKey[x]=x;
	}
	/* Handle loop limit */
	lplmt=atoi(argv[2]);
	/* Read ciphertext */
	if((fi=fopen(argv[3],"rt"))==NULL){
		printf("ERROR: Ciphertext file open failed.\n\n");
		return 1;
	}
	ReadCtext();
	fclose(fi);
	/* Open write file */
	if((fo=fopen(argv[4],"wt"))==NULL){
		printf("ERROR: Write file open failed.\n\n");
		return 1;
	}
	switch(argv[1][1]){
#ifdef RANDOM
			case 'r':
			GenKey=GenKeyR;
			GenType=1;
			break;
#endif
#ifdef SLCTSRCH
		case 's':
			GenKey=GenKeyS;
			GenType=2;
			break;
#endif
#ifdef BBLSRCH
		case 'b':
			GenKey=GenKeyB;
			GenType=3;
			break;
#endif
#ifdef CKTLSRCH
			case 'c':
			GenKey=GenKeyC;
			GenType=4;
			break;
#endif
#ifdef EXPRMNT
		case 'e':
			GenKey=GenKeyE;
			GenType=5;
			break;
#endif
		default:
			printf("ERROR: Illegal Key Generator Selection\n");
			return 1;
	}
	/* Setup pointers so the just the function pointers change. */
	switch(argv[1][0]){
		case '1':
			GenStats=GenStats1;
			break;
		case '2':
			GenStats=GenStats2;
			break;
		case '3':
			GenStats=GenStats3;
			break;
		case '4':
			GenStats=GenStats4;
			break;
		default:
			printf("ERROR: Illegal stat gen selection.\n\n");
			return 1;
	}
	if(argv[1][2]=='s'||argv[1][2]=='S'){
		EnableSG=1;
		if(argv[1][3]>'0'&&argv[1][3]<='9'){
			sglmt=atoi(&argv[1][3]);
		}else{
			sglmt=25;
		}
	}
	/*************************************************************************
	* Loop for Shotgun and perhaps other hill climb variants.
	*************************************************************************/
	sgcnt=0;
	do{
		if(EnableSG==1&&sgcnt!=0)Shotgun();
		HillClimb();
		WriteKey();
		sgcnt++;
	}while(sgcnt<sglmt);
	fclose(fo);
	return 0;
}
void usage(void){
	printf(" usage: HillClmb ntsnn looplmt infile outfile <keyfile>\n");
	printf("n       = 1 mono, 2 digram, 3 trigram, 4 quadgram scoring\n");
	printf("t       = r=random, s=selection, e=experiment\n");
	printf("snn       = s=shotgun and nn= the number of keys to try.\n");
	printf("looplmt = Search loop count limit (typ. 10000)\n");
	printf("infile  = Ciphertext input file\n");
	printf("outfile = Possible key and decrypt file\n");
	printf("keyfile = Optional starting key file (26 letters in any order)\n\n");
	printf("A typical search is around 1000 to 3000 per key (actual - limit)\n\n");
	printf("In shotgun mode, 6 lines of text plus the ciphertext are saved.\n");
	printf("You may want to limit trial run sizes until you get an idea how\n");
	printf("much data is generated.\n");
}
